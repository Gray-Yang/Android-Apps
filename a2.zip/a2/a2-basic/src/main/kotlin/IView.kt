interface IView {
    fun updateView()
}
